import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, Navigate, useNavigate } from "react-router-dom";
import Notification from '../components/Notification';

const ParentTable = () => {
    const [parents, setParents] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const [userData, setUserData] = useState({});
    const navigate = useNavigate();
    const [notificationMessage, setNotificationMessage] = useState('');
    const [showNotification, setShowNotification] = useState(false);
    const [token, setToken] = useState(null);

    useEffect(() => {
        const storedUserData = localStorage.getItem('userData');
        if (storedUserData) {
            const userDataJson = JSON.parse(storedUserData);
            setUserData(userDataJson);
            setToken(userDataJson.token);
        }
    }, []);

    const handleTokenChanged = () => {
        setIsOpen(true);
        setNotificationMessage('Token axpired, Login again');
        setShowNotification(true);
        setTimeout(() => {
            localStorage.removeItem('userData');
            navigate('/login', { replace: true });
        }, 3000); // Wait 3 seconds before redirecting to login page
    };

    const authHeader = {
        'Authorization': `Bearer ${token}`,
    };

    const fetchChildren = async (userId) => {
        try {
            const response = await axios.get(`https://luckyx.cloud/api/v1/user/subtree`, {
                headers: authHeader,
                params: { user_id: userId },
            });
            const { user, sub_left, sub_right } = response.data;
            const children = [];

            if (sub_left) {
                children.push({ name: sub_left.name, side: 'Left' });
                children.push(...(await fetchChildren(sub_left.id)));
            }

            if (sub_right) {
                children.push({ name: sub_right.name, side: 'Right' });
                children.push(...(await fetchChildren(sub_right.id)));
            }

            return children;
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        const authHeader = {
        'Authorization': `Bearer ${token}`,
    };
    

    const fetchChildren = async (userId) => {
        const queue = [{ id: userId, side: null }];
        const children = [];
      
        while (queue.length > 0) {
          const { id, side } = queue.shift();
          try {
            const response = await axios.get(`https://luckyx.cloud/api/v1/user/subtree`, {
              headers: authHeader,
              params: { user_id: id },
            });
            const { user, sub_left, sub_right } = response.data;
      
            if (sub_left) {
              children.push({ name: sub_left.name, side: 'Left' });
              queue.push({ id: sub_left.id, side: 'Left' });
            }
      
            if (sub_right) {
              children.push({ name: sub_right.name, side: 'Right' });
              queue.push({ id: sub_right.id, side: 'Right' });
            }
          } catch (error) {
            console.error(error);
          }
        }
      
        return children;
      };
        const fetchParents = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`https://luckyx.cloud/api/v1/user/subtree`, {
                    headers: authHeader,
                    params: { user_id: userData.id },
                });
                const { user, sub_left, sub_right } = response.data;

                if (user) {
                    const parentsData = await fetchChildren(user.id);
                    setParents(parentsData);
                } else {
                    setParents([]);
                }
            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        };
        fetchParents();
    }, [token, userData]);

    

    return (
        <div style={{backgroundColor: '#f070e8'}} className='container'>
  {loading? (
    <p>Loading...</p>
  ) : (
    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
  <thead>
    <tr>
      <th style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>Name</th>
      <th style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>Image</th>
      <th style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>Side</th>
      <th style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>Reward</th>
    </tr>
  </thead>
  <tbody>
  {parents.map((parent, index) => (
    <tr key={index}>
      <td style={{ padding: '10px' }}>
        {index + 1} {parent.name}
      </td>
      <td>
        <img src={parent.avatar} alt={parent.name} style={{ width: '20px', height: '20px', borderRadius: '50%', marginLeft: '10px' }} />
      </td>
      <td style={{ padding: '10px' }}>{parent.side}</td>
      <td style={{ padding: '10px' }}>0</td>
    </tr>
  ))}
</tbody>
</table>
  )}
</div>
    );
};

export default ParentTable;